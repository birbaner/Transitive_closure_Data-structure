#!/usr/bin/env python
# coding: utf-8

# In[1]:


import sys

def read_graph_from_file(filename):
    with open(filename, 'r') as file:
        lines = file.readlines()

    graphs = []
    graph = []
    for line in lines:
        if line.strip():  # Non-empty line
            row = [int(x) for x in line.strip().split()]
            graph.append(row)
        else:  # Empty line, indicates the end of one matrix
            if graph:
                graphs.append(graph)
                graph = []

    if graph:  # If the last graph was not followed by an empty line
        graphs.append(graph)

    return graphs

def write_transitive_closure_to_file(graph, filename):
    with open(filename, 'w') as file:
        for row in graph:
            file.write(' '.join(str(int(val)) for val in row) + '\n')

def compute_transitive_closure(graph):
    N = len(graph)
    G_plus = [[False for _ in range(N)] for _ in range(N)]

    # Step 1: Initialize G+ with G (paths of length 1)
    for i in range(N):
        for j in range(N):
            G_plus[i][j] = graph[i][j]

    # Step 2 and 3: Compute Gk and update G+ for k = 2 to N
    for k in range(2, N + 1):
        G_k = [[False for _ in range(N)] for _ in range(N)]

        for i in range(N):
            for j in range(N):
                for h in range(N):
                    G_k[i][j] = G_k[i][j] or (G_plus[i][h] and graph[h][j])

        # Update G+ with the computed Gk
        for i in range(N):
            for j in range(N):
                G_plus[i][j] = G_plus[i][j] or G_k[i][j]

    return G_plus

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python program_name.py input_file output_file")
        sys.exit(1)

    input_file = sys.argv[1]
    output_file = sys.argv[2]

    graphs = read_graph_from_file(input_file)

    with open(output_file, 'w') as output:
        for idx, graph in enumerate(graphs):
            transitive_closure = compute_transitive_closure(graph)
            output.write(f"Transitive Closure for Graph {idx + 1}:\n")
            for row in transitive_closure:
                output.write(' '.join(str(int(val)) for val in row) + '\n')
            output.write('\n')  # Add an empty line to separate transitive closures


# In[ ]:




